import server from "./index.js";

server.listen(2047,()=>{
    console.log("Server is running on port 2047");
})