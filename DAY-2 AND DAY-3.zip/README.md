<!-- index.js -->
1. Install - npm i express : cut and paste on terminal.
2. Install - npm i ejs : for view engine..view ejs file
3. Install - npm i express-ejs-layouts