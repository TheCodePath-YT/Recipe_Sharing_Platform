import express from 'express';
import RecipeController from './src/controllers/recipe.controller.js';
import path from 'path';
import expressEjsLayouts from 'express-ejs-layouts';

const server = express();


server.use(express.urlencoded({extended:true}));
server.set("view engine","ejs");
server.set("views",path.join(path.resolve(),"src","views"));
server.use(expressEjsLayouts);


const recipeController = new RecipeController();
server.get('/',recipeController.getRecipe);
server.get('/newRecipe',recipeController.getNewRecipe);
server.post('/',recipeController.postNewRecipe);

server.use(express.static('src/views'))


export default server ;