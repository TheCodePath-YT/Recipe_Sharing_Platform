export default class RecipeModel {
  constructor(id, recipeName, title, desc, image, writtenBy) {
    this.id = id,
      this.recipeName = recipeName,
      this.title = title,
      this.desc = desc,
      this.image = image,
      this.writtenBy = writtenBy;
  }

  static getRecipeData() {
    return RecipeData;
  }
 static addrecipe(recipeData){
    console.log(recipeData);
    const addRecipe = new RecipeModel(
        RecipeData.length+1,
        recipeData.recipeName,
        recipeData.title,
        recipeData.desc,
        recipeData.image,
        recipeData.writtenBy
    )
    RecipeData.push(addRecipe);
  }
}

let RecipeData = [
  new RecipeModel(
    1,
    "Classic Margherita Pizza",
    "How to Make a Classic Margherita Pizza",
    "A simple yet delicious pizza with fresh tomato sauce, mozzarella cheese, and basil leaves, baked to perfection.",
    "../../public/images/1 Pizza.jpg",
    "ChefMaster"
  ),
  new RecipeModel(
    2,
    "Chocolate Lava Cake",
    "How to Make a Chocolate Lava Cake",
    "An indulgent dessert with a rich, gooey chocolate center that's perfect for any occasion.",
    "",
    "BakingQueen"
  ),
  new RecipeModel(
    3,
    "Creamy Mushroom Pasta",
    "How to Make Creamy Mushroom Pasta",
    "A hearty pasta dish with a creamy mushroom sauce, perfect for a quick and comforting meal.",
    "",
    "ChefMaster"
  ),
];
