import path from 'path';
import RecipeModel from '../models/recipe.model.js';

export default class RecipeController{

    getRecipe(req,res){
       const recipeData = RecipeModel.getRecipeData();
       console.log(recipeData);
        res.render('recipe',{recipeData});
    }
    getNewRecipe(req,res){
        res.render('addNewrecipe');
    }
    postNewRecipe(req,res){
        const getrecipeData = req.body;
        RecipeModel.addrecipe(getrecipeData);
        let recipeData = RecipeModel.getRecipeData();
        res.render('recipe',{recipeData});

    }
}