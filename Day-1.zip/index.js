import express from 'express';
import RecipeController from './src/controllers/recipe.controller.js';

const server = express();
const recipeController = new RecipeController();
server.get('/',recipeController.getRecipe);
server.use(express.static('src/views'))
server.listen(2047,()=>{
    console.log("Server is running on port 2047");
})