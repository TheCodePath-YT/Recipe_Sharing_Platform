<!-- index.js -->
1. Install - npm i express : cut and paste on terminal.