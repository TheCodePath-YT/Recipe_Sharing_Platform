import path from 'path';
export default class RecipeController{

    getRecipe(req,res){
       const filePath = path.join(path.resolve(),"src","views","recipe.html");
       console.log(filePath);
        res.sendFile(filePath);
    }
}